﻿namespace SchoolCalc
{
    partial class JackCalc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(JackCalc));
            this.Num1 = new System.Windows.Forms.Button();
            this.Num9 = new System.Windows.Forms.Button();
            this.Num8 = new System.Windows.Forms.Button();
            this.Num7 = new System.Windows.Forms.Button();
            this.Num6 = new System.Windows.Forms.Button();
            this.Num5 = new System.Windows.Forms.Button();
            this.Num4 = new System.Windows.Forms.Button();
            this.Num3 = new System.Windows.Forms.Button();
            this.Num2 = new System.Windows.Forms.Button();
            this.DisplayWindow = new System.Windows.Forms.TextBox();
            this.Div = new System.Windows.Forms.Button();
            this.Multiply = new System.Windows.Forms.Button();
            this.Sub = new System.Windows.Forms.Button();
            this.Result = new System.Windows.Forms.Button();
            this.Num0 = new System.Windows.Forms.Button();
            this.Cull = new System.Windows.Forms.Button();
            this.Plus = new System.Windows.Forms.Button();
            this.Decimal = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.process1 = new System.Diagnostics.Process();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.plusNeg = new System.Windows.Forms.Button();
            this.pi = new System.Windows.Forms.Button();
            this.Inverse = new System.Windows.Forms.Button();
            this.squareRoot = new System.Windows.Forms.Button();
            this.sine = new System.Windows.Forms.Button();
            this.cosine = new System.Windows.Forms.Button();
            this.tan = new System.Windows.Forms.Button();
            this.logButton = new System.Windows.Forms.Button();
            this.inversePow = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Num1
            // 
            this.Num1.Location = new System.Drawing.Point(12, 161);
            this.Num1.Name = "Num1";
            this.Num1.Size = new System.Drawing.Size(35, 34);
            this.Num1.TabIndex = 7;
            this.Num1.Text = "1";
            this.Num1.UseVisualStyleBackColor = true;
            this.Num1.Click += new System.EventHandler(this.Num1_Click);
            // 
            // Num9
            // 
            this.Num9.Location = new System.Drawing.Point(93, 82);
            this.Num9.Name = "Num9";
            this.Num9.Size = new System.Drawing.Size(35, 34);
            this.Num9.TabIndex = 8;
            this.Num9.Text = "9";
            this.Num9.UseVisualStyleBackColor = true;
            this.Num9.Click += new System.EventHandler(this.Num9_Click);
            // 
            // Num8
            // 
            this.Num8.Location = new System.Drawing.Point(53, 82);
            this.Num8.Name = "Num8";
            this.Num8.Size = new System.Drawing.Size(35, 34);
            this.Num8.TabIndex = 9;
            this.Num8.Text = "8";
            this.Num8.UseVisualStyleBackColor = true;
            this.Num8.Click += new System.EventHandler(this.Num8_Click);
            // 
            // Num7
            // 
            this.Num7.Location = new System.Drawing.Point(12, 82);
            this.Num7.Name = "Num7";
            this.Num7.Size = new System.Drawing.Size(35, 34);
            this.Num7.TabIndex = 10;
            this.Num7.Text = "7";
            this.Num7.UseVisualStyleBackColor = true;
            this.Num7.Click += new System.EventHandler(this.Num7_Click);
            // 
            // Num6
            // 
            this.Num6.Location = new System.Drawing.Point(93, 122);
            this.Num6.Name = "Num6";
            this.Num6.Size = new System.Drawing.Size(35, 34);
            this.Num6.TabIndex = 11;
            this.Num6.Text = "6";
            this.Num6.UseVisualStyleBackColor = true;
            this.Num6.Click += new System.EventHandler(this.Num6_Click);
            // 
            // Num5
            // 
            this.Num5.Location = new System.Drawing.Point(53, 122);
            this.Num5.Name = "Num5";
            this.Num5.Size = new System.Drawing.Size(35, 34);
            this.Num5.TabIndex = 12;
            this.Num5.Text = "5";
            this.Num5.UseVisualStyleBackColor = true;
            this.Num5.Click += new System.EventHandler(this.Num5_Click);
            // 
            // Num4
            // 
            this.Num4.Location = new System.Drawing.Point(12, 122);
            this.Num4.Name = "Num4";
            this.Num4.Size = new System.Drawing.Size(35, 34);
            this.Num4.TabIndex = 13;
            this.Num4.Text = "4";
            this.Num4.UseVisualStyleBackColor = true;
            this.Num4.Click += new System.EventHandler(this.Num4_Click);
            // 
            // Num3
            // 
            this.Num3.BackColor = System.Drawing.SystemColors.ControlLight;
            this.Num3.Location = new System.Drawing.Point(93, 162);
            this.Num3.Name = "Num3";
            this.Num3.Size = new System.Drawing.Size(35, 34);
            this.Num3.TabIndex = 14;
            this.Num3.Text = "3";
            this.Num3.UseVisualStyleBackColor = false;
            this.Num3.Click += new System.EventHandler(this.Num3_Click);
            // 
            // Num2
            // 
            this.Num2.Location = new System.Drawing.Point(53, 162);
            this.Num2.Name = "Num2";
            this.Num2.Size = new System.Drawing.Size(35, 34);
            this.Num2.TabIndex = 15;
            this.Num2.Text = "2";
            this.Num2.UseVisualStyleBackColor = true;
            this.Num2.Click += new System.EventHandler(this.Num2_Click);
            // 
            // DisplayWindow
            // 
            this.DisplayWindow.Location = new System.Drawing.Point(12, 27);
            this.DisplayWindow.Name = "DisplayWindow";
            this.DisplayWindow.Size = new System.Drawing.Size(199, 20);
            this.DisplayWindow.TabIndex = 16;
            // 
            // Div
            // 
            this.Div.Location = new System.Drawing.Point(134, 82);
            this.Div.Name = "Div";
            this.Div.Size = new System.Drawing.Size(35, 34);
            this.Div.TabIndex = 18;
            this.Div.Text = "/";
            this.Div.UseVisualStyleBackColor = true;
            this.Div.Click += new System.EventHandler(this.Div_Click);
            // 
            // Multiply
            // 
            this.Multiply.Location = new System.Drawing.Point(134, 122);
            this.Multiply.Name = "Multiply";
            this.Multiply.Size = new System.Drawing.Size(35, 34);
            this.Multiply.TabIndex = 19;
            this.Multiply.Text = "x";
            this.Multiply.UseVisualStyleBackColor = true;
            this.Multiply.Click += new System.EventHandler(this.Multiply_Click);
            // 
            // Sub
            // 
            this.Sub.Location = new System.Drawing.Point(175, 122);
            this.Sub.Name = "Sub";
            this.Sub.Size = new System.Drawing.Size(35, 34);
            this.Sub.TabIndex = 20;
            this.Sub.Text = "-";
            this.Sub.UseVisualStyleBackColor = true;
            this.Sub.Click += new System.EventHandler(this.Sub_Click);
            // 
            // Result
            // 
            this.Result.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Result.Location = new System.Drawing.Point(172, 202);
            this.Result.Name = "Result";
            this.Result.Size = new System.Drawing.Size(35, 92);
            this.Result.TabIndex = 21;
            this.Result.Text = "=";
            this.Result.UseVisualStyleBackColor = true;
            this.Result.Click += new System.EventHandler(this.Result_Click);
            // 
            // Num0
            // 
            this.Num0.Location = new System.Drawing.Point(12, 201);
            this.Num0.Name = "Num0";
            this.Num0.Size = new System.Drawing.Size(116, 34);
            this.Num0.TabIndex = 22;
            this.Num0.Text = "0";
            this.Num0.UseVisualStyleBackColor = true;
            this.Num0.Click += new System.EventHandler(this.Num0_Click);
            // 
            // Cull
            // 
            this.Cull.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Cull.Location = new System.Drawing.Point(134, 242);
            this.Cull.Name = "Cull";
            this.Cull.Size = new System.Drawing.Size(35, 52);
            this.Cull.TabIndex = 23;
            this.Cull.Text = "C";
            this.Cull.UseVisualStyleBackColor = true;
            this.Cull.Click += new System.EventHandler(this.Cull_Click);
            // 
            // Plus
            // 
            this.Plus.Location = new System.Drawing.Point(175, 82);
            this.Plus.Name = "Plus";
            this.Plus.Size = new System.Drawing.Size(35, 34);
            this.Plus.TabIndex = 24;
            this.Plus.Text = "+";
            this.Plus.UseVisualStyleBackColor = true;
            this.Plus.Click += new System.EventHandler(this.Plus_Click);
            // 
            // Decimal
            // 
            this.Decimal.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.Decimal.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Decimal.Location = new System.Drawing.Point(134, 202);
            this.Decimal.Name = "Decimal";
            this.Decimal.Size = new System.Drawing.Size(35, 34);
            this.Decimal.TabIndex = 25;
            this.Decimal.Text = ".";
            this.Decimal.UseVisualStyleBackColor = true;
            this.Decimal.Click += new System.EventHandler(this.Decimal_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(134, 162);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(73, 34);
            this.button1.TabIndex = 26;
            this.button1.Text = "x^2";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // process1
            // 
            this.process1.StartInfo.Domain = "";
            this.process1.StartInfo.LoadUserProfile = false;
            this.process1.StartInfo.Password = null;
            this.process1.StartInfo.StandardErrorEncoding = null;
            this.process1.StartInfo.StandardOutputEncoding = null;
            this.process1.StartInfo.UserName = "";
            this.process1.SynchronizingObject = this;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(219, 24);
            this.menuStrip1.TabIndex = 27;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.helpToolStripMenuItem});
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(52, 20);
            this.aboutToolStripMenuItem.Text = "About";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click_1);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.helpToolStripMenuItem.Text = "Help";
            this.helpToolStripMenuItem.Click += new System.EventHandler(this.helloToolStripMenuItem_Click);
            // 
            // plusNeg
            // 
            this.plusNeg.Location = new System.Drawing.Point(12, 53);
            this.plusNeg.Name = "plusNeg";
            this.plusNeg.Size = new System.Drawing.Size(35, 23);
            this.plusNeg.TabIndex = 28;
            this.plusNeg.Text = "+/-";
            this.plusNeg.UseVisualStyleBackColor = true;
            this.plusNeg.Click += new System.EventHandler(this.plusNeg_Click);
            // 
            // pi
            // 
            this.pi.Location = new System.Drawing.Point(93, 53);
            this.pi.Name = "pi";
            this.pi.Size = new System.Drawing.Size(35, 23);
            this.pi.TabIndex = 29;
            this.pi.Text = "π";
            this.pi.UseVisualStyleBackColor = true;
            this.pi.Click += new System.EventHandler(this.button2_Click);
            // 
            // Inverse
            // 
            this.Inverse.Location = new System.Drawing.Point(134, 53);
            this.Inverse.Name = "Inverse";
            this.Inverse.Size = new System.Drawing.Size(77, 23);
            this.Inverse.TabIndex = 30;
            this.Inverse.Text = "←";
            this.Inverse.UseVisualStyleBackColor = true;
            this.Inverse.Click += new System.EventHandler(this.backspace_Click);
            // 
            // squareRoot
            // 
            this.squareRoot.Location = new System.Drawing.Point(54, 53);
            this.squareRoot.Name = "squareRoot";
            this.squareRoot.Size = new System.Drawing.Size(34, 23);
            this.squareRoot.TabIndex = 31;
            this.squareRoot.Text = "√ ";
            this.squareRoot.UseVisualStyleBackColor = true;
            this.squareRoot.Click += new System.EventHandler(this.squareRoot_Click);
            // 
            // sine
            // 
            this.sine.Location = new System.Drawing.Point(51, 242);
            this.sine.Name = "sine";
            this.sine.Size = new System.Drawing.Size(34, 23);
            this.sine.TabIndex = 32;
            this.sine.Text = "Sin";
            this.sine.UseVisualStyleBackColor = true;
            this.sine.Click += new System.EventHandler(this.sine_Click);
            // 
            // cosine
            // 
            this.cosine.Location = new System.Drawing.Point(12, 242);
            this.cosine.Name = "cosine";
            this.cosine.Size = new System.Drawing.Size(34, 23);
            this.cosine.TabIndex = 33;
            this.cosine.Text = "Cosine";
            this.cosine.UseVisualStyleBackColor = true;
            this.cosine.Click += new System.EventHandler(this.cosine_Click);
            // 
            // tan
            // 
            this.tan.Location = new System.Drawing.Point(91, 242);
            this.tan.Name = "tan";
            this.tan.Size = new System.Drawing.Size(37, 23);
            this.tan.TabIndex = 34;
            this.tan.Text = "Tan";
            this.tan.UseVisualStyleBackColor = true;
            this.tan.Click += new System.EventHandler(this.tan_Click);
            // 
            // logButton
            // 
            this.logButton.Location = new System.Drawing.Point(13, 271);
            this.logButton.Name = "logButton";
            this.logButton.Size = new System.Drawing.Size(34, 23);
            this.logButton.TabIndex = 36;
            this.logButton.Text = "Log";
            this.logButton.UseVisualStyleBackColor = true;
            this.logButton.Click += new System.EventHandler(this.logButton_Click);
            // 
            // inversePow
            // 
            this.inversePow.Location = new System.Drawing.Point(51, 271);
            this.inversePow.Name = "inversePow";
            this.inversePow.Size = new System.Drawing.Size(77, 23);
            this.inversePow.TabIndex = 37;
            this.inversePow.Text = "Inverse Log";
            this.inversePow.UseVisualStyleBackColor = true;
            this.inversePow.Click += new System.EventHandler(this.inversePow_Click);
            // 
            // JackCalc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ClientSize = new System.Drawing.Size(219, 311);
            this.Controls.Add(this.inversePow);
            this.Controls.Add(this.logButton);
            this.Controls.Add(this.tan);
            this.Controls.Add(this.cosine);
            this.Controls.Add(this.sine);
            this.Controls.Add(this.squareRoot);
            this.Controls.Add(this.Inverse);
            this.Controls.Add(this.pi);
            this.Controls.Add(this.plusNeg);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Decimal);
            this.Controls.Add(this.Plus);
            this.Controls.Add(this.Cull);
            this.Controls.Add(this.Num0);
            this.Controls.Add(this.Result);
            this.Controls.Add(this.Sub);
            this.Controls.Add(this.Multiply);
            this.Controls.Add(this.Div);
            this.Controls.Add(this.DisplayWindow);
            this.Controls.Add(this.Num2);
            this.Controls.Add(this.Num3);
            this.Controls.Add(this.Num4);
            this.Controls.Add(this.Num5);
            this.Controls.Add(this.Num6);
            this.Controls.Add(this.Num7);
            this.Controls.Add(this.Num8);
            this.Controls.Add(this.Num9);
            this.Controls.Add(this.Num1);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.HelpButton = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "JackCalc";
            this.Text = "OpenCalc";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Num1;
        private System.Windows.Forms.Button Num9;
        private System.Windows.Forms.Button Num8;
        private System.Windows.Forms.Button Num7;
        private System.Windows.Forms.Button Num6;
        private System.Windows.Forms.Button Num5;
        private System.Windows.Forms.Button Num4;
        private System.Windows.Forms.Button Num3;
        private System.Windows.Forms.Button Num2;
        private System.Windows.Forms.TextBox DisplayWindow;
        private System.Windows.Forms.Button Div;
        private System.Windows.Forms.Button Multiply;
        private System.Windows.Forms.Button Sub;
        private System.Windows.Forms.Button Result;
        private System.Windows.Forms.Button Num0;
        private System.Windows.Forms.Button Cull;
        private System.Windows.Forms.Button Plus;
        private System.Windows.Forms.Button Decimal;
        private System.Windows.Forms.Button button1;
        private System.Diagnostics.Process process1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.Button plusNeg;
        private System.Windows.Forms.Button pi;
        private System.Windows.Forms.Button Inverse;
        private System.Windows.Forms.Button squareRoot;
        private System.Windows.Forms.Button tan;
        private System.Windows.Forms.Button cosine;
        private System.Windows.Forms.Button sine;
        private System.Windows.Forms.Button logButton;
        private System.Windows.Forms.Button inversePow;
    }
}

