﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SchoolCalc
{
    public partial class JackCalc : Form
    {
        string v1, v2, leftPowerValue, rightPowerValue;
        char operation = 'n'; //This is set as n blank purely so leftPowerClick can operate
        string input;
        int count = 0;
        double num1, num2; //This gives global scope prevents squared numbers being overwritten!
        bool decCount = false;
        bool negSign = false;
        bool leftTrigClick = false, rightTrigClick = false, trigClick = true;
        string trigValue; //Used with inverse
        bool trigInverse = false;

        public JackCalc()
        {
            InitializeComponent();
           
        }

        private void button12_Click(object sender, EventArgs e)
        {
            
        }

        private void Num1_Click(object sender, EventArgs e)
        {
            input += 1;
            DisplayWindow.Text = DisplayWindow.Text + "1";
        }

        private void Num2_Click(object sender, EventArgs e)
        {
            input += 2;
            DisplayWindow.Text = DisplayWindow.Text + "2";
        }

        private void Num3_Click(object sender, EventArgs e)
        {
            input += 3;
            DisplayWindow.Text = DisplayWindow.Text + "3";
        }

        private void Num4_Click(object sender, EventArgs e)
        {
            input += 4;
            DisplayWindow.Text = DisplayWindow.Text + "4";
        }

        private void Num5_Click(object sender, EventArgs e)
        {
            input += 5;
            DisplayWindow.Text = DisplayWindow.Text + "5";
        }

        private void Num6_Click(object sender, EventArgs e)
        {
            input += 6;
            DisplayWindow.Text = DisplayWindow.Text + "6";
        }

        private void Num7_Click(object sender, EventArgs e)
        {
            input += 7;
            DisplayWindow.Text = DisplayWindow.Text + "7";
        }

        private void Num8_Click(object sender, EventArgs e)
        {
            input += 8;
            DisplayWindow.Text = DisplayWindow.Text + "8";
        }

        private void Num9_Click(object sender, EventArgs e)
        {
            input += 9;
            DisplayWindow.Text = DisplayWindow.Text + "9";
        }

        private void Num0_Click(object sender, EventArgs e)
        {
            input += 0;
            DisplayWindow.Text = DisplayWindow.Text + "0";
        }

        private void Cull_Click(object sender, EventArgs e)
        {
            //Kill Everything
            v1 = string.Empty;
            v2 = string.Empty;
            DisplayWindow.Text = string.Empty;
            input = string.Empty;
            decCount = false;
            negSign = false;
            operation = 'n'; //default back to 'n' so y^x continues to operate normally
            leftTrigClick = false;
            rightTrigClick = false;
            trigInverse = false;
            Plus.BackColor = Color.LightGray;
            Sub.BackColor = Color.LightGray;
            Div.BackColor = Color.LightGray;
            Multiply.BackColor = Color.LightGray;
        }

        private void Plus_Click(object sender, EventArgs e)
        {
            //On click will plus
            operation = '+';

            if (leftTrigClick == false)
            {
                v1 = input;
            }
            input = string.Empty;
            Plus.BackColor = Color.Red;
            decCount = false;
            negSign = false;
            DisplayWindow.Text = "";
        }

        private void Div_Click(object sender, EventArgs e)
        {
            operation = '/';
            if (leftTrigClick == false)
            {
                v1 = input;
            }
            input = string.Empty;
            Div.BackColor = Color.Red;
            decCount = false;
            negSign = false;
            DisplayWindow.Text = "";
        }

        private void Multiply_Click(object sender, EventArgs e)
        {
            operation = '*';
            if (leftTrigClick == false)
            {
                v1 = input;
            }
            input = string.Empty;
            Multiply.BackColor = Color.Red;
            decCount = false;
            negSign = false;
            DisplayWindow.Text = "";
        }

        private void Sub_Click(object sender, EventArgs e)
        {
            operation = '-';
            if (leftTrigClick == false)
            {
                v1 = input;
            }
            input = string.Empty;
            Sub.BackColor = Color.Red;
            count = 0;
            negSign = false;
            DisplayWindow.Text = "";
        }

        private void Result_Click(object sender, EventArgs e)
        {
            double result = 0;


            if (trigClick == true)
            {
                if (leftTrigClick == true)
                {
                    if (trigInverse == true) // if this is true then inverse trigonometry is used. 
                    {
                        if (trigValue == "sin")
                        {
                            num1 = Math.Asin(num1 * Math.PI / 180);
                        }
                        if (trigValue == "cos")
                        {
                            num1 = Math.Acos(num1 * Math.PI / 180);
                        }
                        if (trigValue == "tan")
                        {
                            num1 = Math.Atan(num1 * Math.PI / 180);
                        }
                    }
                    if (trigInverse == false)
                    {
                        if (trigValue == "sin")
                        {
                            num1 = Math.Sin(num1 * Math.PI / 180);
                        }
                        if (trigValue == "cos")
                        {
                            num1 = Math.Cos(num1 * Math.PI / 180);
                        }
                        if (trigValue == "tan")
                        {
                            num1 = Math.Tan(num1 * Math.PI / 180);
                        }
                    }

                    if (rightTrigClick == true)
                    {
                        if (trigValue == "sin")
                        {
                            num2 = Math.Sin(num2 * Math.PI / 180);
                        }
                        if (trigValue == "cos")
                        {
                            num1 = Math.Cos(num2 * Math.PI / 180);
                        }
                        if (trigValue == "tan")
                        {
                            num1 = Math.Tan(num2 * Math.PI / 180);
                        }
                    }
                }

                v2 = input; //assigns the second string entered to v2

                if (leftTrigClick == false)
                {
                    double.TryParse(v1, out num1); //assigns num1 with the contents of string v1

                }
                if (rightTrigClick == false)
                {
                    double.TryParse(v2, out num2); //assigns num2 with the contents of string v2
                }


                if (operation == '+')
                {
                    result = num1 + num2;
                    DisplayWindow.Text = result.ToString();
                    decCount = false;
                    negSign = false;
                }

                if (operation == '-')
                {
                    result = num1 - num2;
                    DisplayWindow.Text = result.ToString();
                    decCount = false;
                    negSign = false;
                }

                if (operation == '*')
                {
                    result = num1 * num2;
                    DisplayWindow.Text = result.ToString();
                    decCount = false;
                    negSign = false;
                }

                if (operation == '/')
                {
                    result = num1 / num2;
                    DisplayWindow.Text = result.ToString();
                    decCount = false;
                    negSign = false;
                }

                input = result.ToString();
            }
       }
            

        private void Decimal_Click(object sender, EventArgs e)
        {   
            if (decCount == false)
            {
                input += '.'; //Allows user to use decimal providing one hasnt already been used
                DisplayWindow.Text = DisplayWindow.Text + ".";
                decCount = true;
            }
            else if (decCount == true)//prevents multiple decimals being used
            {
                DisplayWindow.Text = DisplayWindow.Text;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            v1 = input;
            double num1;
            double.TryParse(v1, out num1); //assigns num1 with the contents of string v1
            double result;
            result = num1 * num1;
            num1 = result;
            input = result.ToString();
            DisplayWindow.Text = result.ToString();
            count = 0; //Reset decimal count
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void aboutToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.MessageBox.Show("1. Insert First Number, 2. Select trigonometry value if desired, 3. Select Operation, 4. Insert second number, 5. Select trigonmetry value if desired, 6. Press Equals");
        }


        private void plusNeg_Click(object sender, EventArgs e)
        {
            if (negSign == false)
            {
                input = "-" + input;
                DisplayWindow.Text = "-" + DisplayWindow.Text;
                negSign = true;
            }
            else if (negSign == true)
            {
                DisplayWindow.Text = DisplayWindow.Text.Remove(0, 1);
                input = input.Remove(0, 1);
                negSign = false;
            }

        }

        private void button2_Click(object sender, EventArgs e) //change to pi!
        {
            input = "3.14159265359";
            DisplayWindow.Text = "3.14159265359";
        }

        private void backspace_Click(object sender, EventArgs e)
        {
            if (DisplayWindow.TextLength > 0)
            {
                DisplayWindow.Text = DisplayWindow.Text.Remove(DisplayWindow.Text.Length - 1);
            }
            else if (DisplayWindow.TextLength == 0)
            {
                DisplayWindow.Text = "Insert numbers first!";
            }

            if (DisplayWindow.Text == "Insert numbers first")
            {
                DisplayWindow.Text = "";
            }
        }

        private void squareRoot_Click(object sender, EventArgs e)
        {
            v1 = input;
            double num1;
            double.TryParse(v1, out num1); //assigns num1 with the contents of string v1
            double result;
            result = Math.Sqrt(num1);
            num1 = result;
            input = result.ToString();
            DisplayWindow.Text = result.ToString();

        }

        

        private void cosine_Click(object sender, EventArgs e)
        {
            trigValue = "cos";
            DisplayWindow.Text += "cos";

            if (operation == 'n') //operation is yet to be pressed and thus the user wishes to pow the first number entered
            {
                v1 = input;
                num1 = Convert.ToDouble(v1); 
                v1 = "";
                input = ""; // reset this to get proper result!
                leftTrigClick = true;
                
            }
            else
            {
                leftTrigClick = true;
                v2 = input;
                num2 = Convert.ToDouble(v2);
                v2 = "";
                input = "";
            }
            
            
        }

        private void sine_Click(object sender, EventArgs e)
        {

           
            if (operation == 'n') //operation is yet to be pressed and thus the user wishes to pow the first number entered
            {
                v1 = input;
                num1 = Convert.ToDouble(v1);
                v1 = "";
                input = ""; // reset this to get proper result!
                leftTrigClick = true;
                
            }
            else
            {
                rightTrigClick = true;
                v2 = input;
                num2 = Convert.ToDouble(v2);
                v2 = "";
                input = "";
            }
            trigValue = "sin";
            DisplayWindow.Text += "sin";
    
           }

        private void tan_Click(object sender, EventArgs e)
        {
            trigValue = "tan";
            DisplayWindow.Text = "tan";
            
            if (operation == 'n') //operation is yet to be pressed and thus the user wishes to pow the first number entered
            {
                v1 = input;
                num1 = Convert.ToDouble(v1);
                v1 = "";
                input = ""; // reset this to get proper result!
                leftTrigClick = true;

            }
            else
            {
                leftTrigClick = true;
                v2 = input;
                num2 = Convert.ToDouble(v2);
                v2 = "";
                input = "";
            }           
        }

        private void logButton_Click(object sender, EventArgs e)
        {

            v1 = input;
            double num1;
            double.TryParse(v1, out num1); //assigns num1 with the contents of string v1
            double result;
            result = Math.Log10(num1);


            num1 = result;
            input = result.ToString();


            DisplayWindow.Text = result.ToString();
        }

        private void inversePow_Click(object sender, EventArgs e)
        {
            v1 = input;
            double num1;
            double.TryParse(v1, out num1); //assigns num1 with the contents of string v1
            double result;
            result = Math.Pow(10, num1); //POW!!!!!!!!!!!!!!


            num1 = result;
            input = result.ToString();
            DisplayWindow.Text = result.ToString();
        }

        private void helloToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.MessageBox.Show("1. Insert First Number, 2. Select trigonometry value if desired, 3. Select Operation, 4. Insert second number, 5. Select trigonmetry value if desired, 6. Press Equals");
        }

        private void aboutToolStripMenuItem_Click_1(object sender, EventArgs e)
        {

        }


      
    }
}
